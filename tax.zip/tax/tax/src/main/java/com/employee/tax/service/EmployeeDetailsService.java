package com.employee.tax.service;

import com.employee.tax.entity.Employee;
import com.employee.tax.vo.EmployeeDetails;

public interface EmployeeDetailsService {

	boolean saveEmployeeDeatils(EmployeeDetails details) throws Exception;
	EmployeeDetails getEmployeeDetails(long employeeid) throws Exception;
}
