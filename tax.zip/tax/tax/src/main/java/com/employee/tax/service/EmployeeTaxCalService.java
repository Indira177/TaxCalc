package com.employee.tax.service;

import com.employee.tax.vo.EmployeeDetails;

public interface EmployeeTaxCalService {

	public EmployeeDetails calculateTax(long employeeid);
}
